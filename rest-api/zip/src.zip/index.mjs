// src/index.ts
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, PutCommand, ScanCommand, DeleteCommand, QueryCommand } from "@aws-sdk/lib-dynamodb";
var client = new DynamoDBClient({});
var dynamo = DynamoDBDocumentClient.from(client);
var tableName = process.env.TABLE_NAME;
var handler = async (event) => {
  let statusCode = 200;
  let body;
  console.log("Received Event: ", event);
  try {
    if (event.httpMethod === "DELETE" && event.path === "/delete" && event.body) {
      const inputObj = typeof event.body === "string" ? JSON.parse(event.body) : event.body;
      await deleteData(inputObj.game_id, inputObj.player_id);
      body = `Deleted item ${JSON.stringify(inputObj)}`;
    } else if (event.httpMethod === "POST" && event.path === "/get-by-id" && event.body) {
      const inputObj = typeof event.body === "string" ? JSON.parse(event.body) : event.body;
      body = await getItemsByGameIdAndPlayerId(inputObj.game_id, inputObj.player_id);
    } else if (event.httpMethod === "GET" && event.path === "/get") {
      body = await getAllItems();
    } else if (event.httpMethod === "POST" && event.path === "/put" && event.body) {
      const inputObj = typeof event.body === "string" ? JSON.parse(event.body) : event.body;
      await insertData(inputObj);
      body = `Put item ${JSON.stringify(inputObj)}`;
    }
  } catch (err) {
    console.error("Error:", err);
    statusCode = 400;
    body = err;
  } finally {
    return {
      statusCode,
      body: JSON.stringify(body),
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Origin": "*"
        // DO NOT USE IN PRODUCTION
      }
    };
  }
};
var getAllItems = async () => {
  console.log("tablename: ", tableName);
  const data = await dynamo.send(new ScanCommand({ TableName: tableName }));
  return data.Items || [];
};
var insertData = async (input) => {
  await dynamo.send(
    new PutCommand({
      TableName: tableName,
      Item: input
    })
  );
  console.log(`Success - item added or updated: ${JSON.stringify(input)}`);
};
var deleteData = async (game_id, player_id) => {
  await dynamo.send(
    new DeleteCommand({
      TableName: tableName,
      Key: { game_id, player_id }
    })
  );
  console.log(`Success - item deleted: ${JSON.stringify({ "game_id": game_id, "player_id": player_id })}`);
};
var getItemsByGameIdAndPlayerId = async (gameId, playerId) => {
  const params = {
    TableName: tableName,
    KeyConditionExpression: "game_id = :gameId AND player_id = :playerId",
    ExpressionAttributeValues: {
      ":gameId": gameId,
      ":playerId": playerId
    }
  };
  const data = await dynamo.send(new QueryCommand(params));
  return data.Items || [];
};
export {
  handler
};
//# sourceMappingURL=index.mjs.map
